package com.example.kfinoneapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class PincodeActivity extends AppCompatActivity {
    private AutoCompleteTextView stateDropdown;
    private AutoCompleteTextView locationDropdown;
    private AutoCompleteTextView subLocationDropdown;
    private TextInputEditText pincodeInput;
    private MaterialButton submitButton;
    private RecyclerView pincodesRecyclerView;
    private PincodeAdapter pincodeAdapter;
    private List<Pincode> pincodes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pincode);

        // Initialize views
        stateDropdown = findViewById(R.id.stateDropdown);
        locationDropdown = findViewById(R.id.locationDropdown);
        subLocationDropdown = findViewById(R.id.subLocationDropdown);
        pincodeInput = findViewById(R.id.pincodeInput);
        submitButton = findViewById(R.id.submitButton);
        pincodesRecyclerView = findViewById(R.id.pincodesRecyclerView);

        // Setup back button
        findViewById(R.id.backButton).setOnClickListener(v -> finish());

        // Setup state dropdown
        String[] states = {"Maharashtra", "Karnataka", "Tamil Nadu", "Gujarat"}; // Example states
        ArrayAdapter<String> stateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, states);
        stateDropdown.setAdapter(stateAdapter);

        // Setup location dropdown
        String[] locations = {"Mumbai", "Bangalore", "Chennai", "Ahmedabad"}; // Example locations
        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, locations);
        locationDropdown.setAdapter(locationAdapter);

        // Setup sub-location dropdown
        String[] subLocations = {"Andheri", "Koramangala", "T Nagar", "Navrangpura"}; // Example sub-locations
        ArrayAdapter<String> subLocationAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, subLocations);
        subLocationDropdown.setAdapter(subLocationAdapter);

        // Setup RecyclerView
        pincodes = new ArrayList<>();
        pincodeAdapter = new PincodeAdapter(pincodes);
        pincodesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        pincodesRecyclerView.setAdapter(pincodeAdapter);

        // Add some sample data
        pincodes.add(new Pincode("400093", "Maharashtra", "Mumbai", "Andheri", "Active"));
        pincodes.add(new Pincode("560034", "Karnataka", "Bangalore", "Koramangala", "Active"));
        pincodeAdapter.notifyDataSetChanged();

        // Setup submit button
        submitButton.setOnClickListener(v -> {
            String selectedState = stateDropdown.getText().toString();
            String selectedLocation = locationDropdown.getText().toString();
            String selectedSubLocation = subLocationDropdown.getText().toString();
            String pincode = pincodeInput.getText().toString();

            if (selectedState.isEmpty() || selectedLocation.isEmpty() || selectedSubLocation.isEmpty() || pincode.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (pincode.length() != 6) {
                Toast.makeText(this, "PIN Code must be 6 digits", Toast.LENGTH_SHORT).show();
                return;
            }

            // Add new pincode
            pincodes.add(new Pincode(pincode, selectedState, selectedLocation, selectedSubLocation, "Active"));
            pincodeAdapter.notifyItemInserted(pincodes.size() - 1);

            // Clear inputs
            stateDropdown.setText("");
            locationDropdown.setText("");
            subLocationDropdown.setText("");
            pincodeInput.setText("");
        });
    }

    // Pincode data class
    private static class Pincode {
        String code;
        String state;
        String location;
        String subLocation;
        String status;

        Pincode(String code, String state, String location, String subLocation, String status) {
            this.code = code;
            this.state = state;
            this.location = location;
            this.subLocation = subLocation;
            this.status = status;
        }
    }

    // RecyclerView Adapter
    private class PincodeAdapter extends RecyclerView.Adapter<PincodeAdapter.PincodeViewHolder> {
        private List<Pincode> pincodes;

        PincodeAdapter(List<Pincode> pincodes) {
            this.pincodes = pincodes;
        }

        @Override
        public PincodeViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            View view = getLayoutInflater().inflate(R.layout.item_pincode, parent, false);
            return new PincodeViewHolder(view);
        }

        @Override
        public void onBindViewHolder(PincodeViewHolder holder, int position) {
            Pincode pincode = pincodes.get(position);
            holder.pincode.setText(pincode.code);
            holder.stateName.setText(pincode.state);
            holder.locationName.setText(pincode.location);
            holder.subLocationName.setText(pincode.subLocation);
            holder.status.setText(pincode.status);

            holder.editButton.setOnClickListener(v -> {
                // TODO: Implement edit functionality
                Toast.makeText(PincodeActivity.this, "Edit clicked for " + pincode.code, Toast.LENGTH_SHORT).show();
            });

            holder.deleteButton.setOnClickListener(v -> {
                pincodes.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, pincodes.size());
            });
        }

        @Override
        public int getItemCount() {
            return pincodes.size();
        }

        class PincodeViewHolder extends RecyclerView.ViewHolder {
            TextView pincode;
            TextView stateName;
            TextView locationName;
            TextView subLocationName;
            TextView status;
            ImageButton editButton;
            ImageButton deleteButton;

            PincodeViewHolder(View itemView) {
                super(itemView);
                pincode = itemView.findViewById(R.id.pincode);
                stateName = itemView.findViewById(R.id.stateName);
                locationName = itemView.findViewById(R.id.locationName);
                subLocationName = itemView.findViewById(R.id.subLocationName);
                status = itemView.findViewById(R.id.status);
                editButton = itemView.findViewById(R.id.editButton);
                deleteButton = itemView.findViewById(R.id.deleteButton);
            }
        }
    }
} 