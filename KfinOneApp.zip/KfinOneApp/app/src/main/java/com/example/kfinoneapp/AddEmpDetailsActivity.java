package com.example.kfinoneapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class AddEmpDetailsActivity extends AppCompatActivity {
    private TextInputEditText firstNameInput, lastNameInput, empIdInput, passwordInput;
    private TextInputEditText personalPhoneInput, personalEmailInput;
    private TextInputEditText officialPhoneInput, officialEmailInput;
    private TextInputEditText aadhaarInput, panInput;
    private TextInputEditText accountNumberInput, ifscInput;
    private AutoCompleteTextView branchStateDropdown, branchLocationDropdown;
    private AutoCompleteTextView departmentDropdown, designationDropdown;
    private AutoCompleteTextView bankNameDropdown, accountTypeDropdown;
    private AutoCompleteTextView reportingToDropdown;
    private TextInputEditText presentAddressInput, permanentAddressInput;
    private MaterialButton uploadPanButton, uploadAadhaarButton;
    private MaterialButton uploadBankProofButton, uploadEmpImageButton;
    private MaterialButton submitButton;

    private Uri panCardUri, aadhaarCardUri, bankProofUri, empImageUri;

    private final ActivityResultLauncher<String> panCardLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    panCardUri = uri;
                    uploadPanButton.setText("Pan Card Uploaded");
                }
            });

    private final ActivityResultLauncher<String> aadhaarCardLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    aadhaarCardUri = uri;
                    uploadAadhaarButton.setText("Aadhaar Card Uploaded");
                }
            });

    private final ActivityResultLauncher<String> bankProofLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    bankProofUri = uri;
                    uploadBankProofButton.setText("Bank Proof Uploaded");
                }
            });

    private final ActivityResultLauncher<String> empImageLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    empImageUri = uri;
                    uploadEmpImageButton.setText("Employee Image Uploaded");
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_emp_details);

        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Initialize views
        initializeViews();
        setupDropdowns();
        setupUploadButtons();
        setupSubmitButton();
    }

    private void initializeViews() {
        firstNameInput = findViewById(R.id.firstNameInput);
        lastNameInput = findViewById(R.id.lastNameInput);
        empIdInput = findViewById(R.id.employeeIdInput);
        passwordInput = findViewById(R.id.passwordInput);
        personalPhoneInput = findViewById(R.id.personalPhoneInput);
        personalEmailInput = findViewById(R.id.personalEmailInput);
        officialPhoneInput = findViewById(R.id.officialPhoneInput);
        officialEmailInput = findViewById(R.id.officialEmailInput);
        branchStateDropdown = findViewById(R.id.branchStateInput);
        branchLocationDropdown = findViewById(R.id.branchLocationInput);
        departmentDropdown = findViewById(R.id.departmentInput);
        designationDropdown = findViewById(R.id.designationInput);
        aadhaarInput = findViewById(R.id.aadhaarNumberInput);
        panInput = findViewById(R.id.panNumberInput);
        accountNumberInput = findViewById(R.id.accountNumberInput);
        ifscInput = findViewById(R.id.ifscCodeInput);
        bankNameDropdown = findViewById(R.id.bankNameInput);
        accountTypeDropdown = findViewById(R.id.accountTypeInput);
        uploadPanButton = findViewById(R.id.panCardUploadButton);
        uploadAadhaarButton = findViewById(R.id.aadhaarCardUploadButton);
        uploadBankProofButton = findViewById(R.id.bankProofUploadButton);
        uploadEmpImageButton = findViewById(R.id.employeeImageUploadButton);
        presentAddressInput = findViewById(R.id.presentAddressInput);
        permanentAddressInput = findViewById(R.id.permanentAddressInput);
        reportingToDropdown = findViewById(R.id.reportingToInput);
        submitButton = findViewById(R.id.submitButton);
    }

    private void setupDropdowns() {
        // Branch States
        String[] states = {"Andhra Pradesh", "Karnataka", "Tamil Nadu", "Telangana", "Kerala"};
        ArrayAdapter<String> statesAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, states);
        branchStateDropdown.setAdapter(statesAdapter);

        // Branch Locations (example for Karnataka)
        String[] locations = {"Bangalore", "Mysore", "Hubli", "Mangalore", "Belgaum"};
        ArrayAdapter<String> locationsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, locations);
        branchLocationDropdown.setAdapter(locationsAdapter);

        // Departments
        String[] departments = {"Sales", "Operations", "HR", "Finance", "IT"};
        ArrayAdapter<String> departmentsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, departments);
        departmentDropdown.setAdapter(departmentsAdapter);

        // Designations
        String[] designations = {"Manager", "Senior Executive", "Executive", "Assistant", "Trainee"};
        ArrayAdapter<String> designationsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, designations);
        designationDropdown.setAdapter(designationsAdapter);

        // Bank Names
        String[] banks = {"SBI", "HDFC", "ICICI", "Axis", "Kotak"};
        ArrayAdapter<String> banksAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, banks);
        bankNameDropdown.setAdapter(banksAdapter);

        // Account Types
        String[] accountTypes = {"Savings", "Current", "Salary"};
        ArrayAdapter<String> accountTypesAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, accountTypes);
        accountTypeDropdown.setAdapter(accountTypesAdapter);

        // Reporting To
        String[] reportingManagers = {"John Doe", "Jane Smith", "Mike Johnson", "Sarah Williams"};
        ArrayAdapter<String> reportingAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, reportingManagers);
        reportingToDropdown.setAdapter(reportingAdapter);
    }

    private void setupUploadButtons() {
        uploadPanButton.setOnClickListener(v -> panCardLauncher.launch("application/pdf"));
        uploadAadhaarButton.setOnClickListener(v -> aadhaarCardLauncher.launch("application/pdf"));
        uploadBankProofButton.setOnClickListener(v -> bankProofLauncher.launch("application/pdf"));
        uploadEmpImageButton.setOnClickListener(v -> empImageLauncher.launch("image/*"));
    }

    private void setupSubmitButton() {
        submitButton.setOnClickListener(v -> {
            if (validateForm()) {
                // TODO: Implement form submission logic
                Toast.makeText(this, "Form submitted successfully!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private boolean validateForm() {
        boolean isValid = true;
        List<String> errors = new ArrayList<>();

        // Validate required fields
        if (firstNameInput.getText().toString().trim().isEmpty()) {
            errors.add("First Name is required");
            isValid = false;
        }
        if (lastNameInput.getText().toString().trim().isEmpty()) {
            errors.add("Last Name is required");
            isValid = false;
        }
        if (empIdInput.getText().toString().trim().isEmpty()) {
            errors.add("Employee ID is required");
            isValid = false;
        }
        if (passwordInput.getText().toString().trim().isEmpty()) {
            errors.add("Password is required");
            isValid = false;
        }
        if (personalPhoneInput.getText().toString().trim().isEmpty()) {
            errors.add("Personal Phone Number is required");
            isValid = false;
        }
        if (personalEmailInput.getText().toString().trim().isEmpty()) {
            errors.add("Personal Email is required");
            isValid = false;
        }
        if (officialPhoneInput.getText().toString().trim().isEmpty()) {
            errors.add("Official Phone Number is required");
            isValid = false;
        }
        if (officialEmailInput.getText().toString().trim().isEmpty()) {
            errors.add("Official Email is required");
            isValid = false;
        }
        if (branchStateDropdown.getText().toString().trim().isEmpty()) {
            errors.add("Branch State is required");
            isValid = false;
        }
        if (branchLocationDropdown.getText().toString().trim().isEmpty()) {
            errors.add("Branch Location is required");
            isValid = false;
        }
        if (departmentDropdown.getText().toString().trim().isEmpty()) {
            errors.add("Department is required");
            isValid = false;
        }
        if (designationDropdown.getText().toString().trim().isEmpty()) {
            errors.add("Designation is required");
            isValid = false;
        }
        if (aadhaarInput.getText().toString().trim().isEmpty()) {
            errors.add("Aadhaar Number is required");
            isValid = false;
        }
        if (panInput.getText().toString().trim().isEmpty()) {
            errors.add("PAN Number is required");
            isValid = false;
        }
        if (accountNumberInput.getText().toString().trim().isEmpty()) {
            errors.add("Account Number is required");
            isValid = false;
        }
        if (ifscInput.getText().toString().trim().isEmpty()) {
            errors.add("IFSC Code is required");
            isValid = false;
        }
        if (bankNameDropdown.getText().toString().trim().isEmpty()) {
            errors.add("Bank Name is required");
            isValid = false;
        }
        if (accountTypeDropdown.getText().toString().trim().isEmpty()) {
            errors.add("Account Type is required");
            isValid = false;
        }
        if (presentAddressInput.getText().toString().trim().isEmpty()) {
            errors.add("Present Address is required");
            isValid = false;
        }
        if (permanentAddressInput.getText().toString().trim().isEmpty()) {
            errors.add("Permanent Address is required");
            isValid = false;
        }
        if (reportingToDropdown.getText().toString().trim().isEmpty()) {
            errors.add("Reporting To is required");
            isValid = false;
        }

        // Validate document uploads
        if (panCardUri == null) {
            errors.add("Pan Card upload is required");
            isValid = false;
        }
        if (aadhaarCardUri == null) {
            errors.add("Aadhaar Card upload is required");
            isValid = false;
        }
        if (bankProofUri == null) {
            errors.add("Bank Proof upload is required");
            isValid = false;
        }
        if (empImageUri == null) {
            errors.add("Employee Image upload is required");
            isValid = false;
        }

        if (!isValid) {
            StringBuilder errorMessage = new StringBuilder("Please fix the following errors:\n");
            for (String error : errors) {
                errorMessage.append("\n• ").append(error);
            }
            Toast.makeText(this, errorMessage.toString(), Toast.LENGTH_LONG).show();
        }

        return isValid;
    }
} 