package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class BanksActivity extends AppCompatActivity {
    private TextInputEditText bankNameInput;
    private MaterialButton addBankButton;
    private RecyclerView banksRecyclerView;
    private BanksAdapter banksAdapter;
    private List<BankItem> banksList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_banks);

        // Initialize views
        initializeViews();
        
        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Set up add bank button
        addBankButton.setOnClickListener(v -> handleAddBank());

        // Set up RecyclerView
        setupRecyclerView();
    }

    private void initializeViews() {
        bankNameInput = findViewById(R.id.bankNameInput);
        addBankButton = findViewById(R.id.addBankButton);
        banksRecyclerView = findViewById(R.id.banksRecyclerView);
    }

    private void setupRecyclerView() {
        banksList = new ArrayList<>();
        banksAdapter = new BanksAdapter(banksList);
        banksRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        banksRecyclerView.setAdapter(banksAdapter);
    }

    private void handleAddBank() {
        String bankName = bankNameInput.getText().toString().trim();
        if (!bankName.isEmpty()) {
            BankItem newBank = new BankItem(bankName, "Active");
            banksList.add(newBank);
            banksAdapter.notifyItemInserted(banksList.size() - 1);
            bankNameInput.setText("");
        }
    }
} 