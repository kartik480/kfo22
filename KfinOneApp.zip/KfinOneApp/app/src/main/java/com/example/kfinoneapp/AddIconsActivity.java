package com.example.kfinoneapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class AddIconsActivity extends AppCompatActivity {
    private TextInputEditText iconNameInput;
    private TextInputEditText urlNameInput;
    private TextInputEditText descriptionInput;
    private MaterialCardView chooseFileCard;
    private MaterialButton submitButton;
    private RecyclerView iconsRecyclerView;
    private IconAdapter iconAdapter;
    private List<IconItem> icons;
    private Uri selectedImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_icons);

        // Initialize views
        iconNameInput = findViewById(R.id.iconNameInput);
        urlNameInput = findViewById(R.id.urlNameInput);
        descriptionInput = findViewById(R.id.descriptionInput);
        chooseFileCard = findViewById(R.id.chooseFileCard);
        submitButton = findViewById(R.id.submitButton);
        iconsRecyclerView = findViewById(R.id.iconsRecyclerView);

        // Setup back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Initialize RecyclerView
        icons = new ArrayList<>();
        iconAdapter = new IconAdapter(icons);
        iconsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        iconsRecyclerView.setAdapter(iconAdapter);

        // Setup file chooser
        chooseFileCard.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            startActivityForResult(intent, 1);
        });

        // Setup submit button
        submitButton.setOnClickListener(v -> {
            String name = iconNameInput.getText().toString().trim();
            String urlName = urlNameInput.getText().toString().trim();
            String description = descriptionInput.getText().toString().trim();

            if (name.isEmpty() || urlName.isEmpty() || description.isEmpty() || selectedImageUri == null) {
                // Show error message
                return;
            }

            // Create new icon item
            IconItem newIcon = new IconItem(name, description, selectedImageUri.toString(), urlName);
            iconAdapter.addIcon(newIcon);

            // Clear inputs
            iconNameInput.setText("");
            urlNameInput.setText("");
            descriptionInput.setText("");
            selectedImageUri = null;
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            // TODO: Show selected image preview
        }
    }
} 