package com.example.kfinoneapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class BranchStateActivity extends AppCompatActivity {
    private TextInputEditText branchStateInput;
    private MaterialButton submitButton;
    private RecyclerView branchStatesRecyclerView;
    private BranchStateAdapter adapter;
    private List<BranchState> branchStates;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_branch_state);

        // Initialize views
        branchStateInput = findViewById(R.id.branchStateInput);
        submitButton = findViewById(R.id.submitButton);
        branchStatesRecyclerView = findViewById(R.id.branchStatesRecyclerView);
        ImageButton backButton = findViewById(R.id.backButton);

        // Setup RecyclerView
        branchStates = new ArrayList<>();
        adapter = new BranchStateAdapter(branchStates);
        branchStatesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        branchStatesRecyclerView.setAdapter(adapter);

        // Back button click listener
        backButton.setOnClickListener(v -> finish());

        // Submit button click listener
        submitButton.setOnClickListener(v -> {
            String branchStateName = branchStateInput.getText().toString().trim();
            if (!branchStateName.isEmpty()) {
                // Add new branch state
                BranchState newBranchState = new BranchState(branchStateName, "Active");
                branchStates.add(newBranchState);
                adapter.notifyItemInserted(branchStates.size() - 1);
                branchStateInput.setText("");
                Toast.makeText(this, "Branch State added successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please enter branch state name", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Branch State data class
    private static class BranchState {
        private String name;
        private String status;

        public BranchState(String name, String status) {
            this.name = name;
            this.status = status;
        }

        public String getName() {
            return name;
        }

        public String getStatus() {
            return status;
        }
    }

    // RecyclerView Adapter
    private class BranchStateAdapter extends RecyclerView.Adapter<BranchStateAdapter.ViewHolder> {
        private List<BranchState> branchStates;

        public BranchStateAdapter(List<BranchState> branchStates) {
            this.branchStates = branchStates;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            View view = getLayoutInflater().inflate(R.layout.item_branch_state, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            BranchState branchState = branchStates.get(position);
            holder.branchStateName.setText(branchState.getName());
            holder.branchStateStatus.setText(branchState.getStatus());

            holder.editButton.setOnClickListener(v -> {
                // TODO: Implement edit functionality
                Toast.makeText(BranchStateActivity.this, "Edit clicked for " + branchState.getName(), Toast.LENGTH_SHORT).show();
            });

            holder.deleteButton.setOnClickListener(v -> {
                branchStates.remove(position);
                notifyItemRemoved(position);
                Toast.makeText(BranchStateActivity.this, "Branch State deleted", Toast.LENGTH_SHORT).show();
            });
        }

        @Override
        public int getItemCount() {
            return branchStates.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView branchStateName;
            TextView branchStateStatus;
            ImageButton editButton;
            ImageButton deleteButton;

            ViewHolder(View itemView) {
                super(itemView);
                branchStateName = itemView.findViewById(R.id.branchStateName);
                branchStateStatus = itemView.findViewById(R.id.branchStateStatus);
                editButton = itemView.findViewById(R.id.editButton);
                deleteButton = itemView.findViewById(R.id.deleteButton);
            }
        }
    }
} 