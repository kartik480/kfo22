package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class StateActivity extends AppCompatActivity {
    private TextInputEditText stateInput;
    private RecyclerView statesRecyclerView;
    private StateAdapter stateAdapter;
    private List<StateItem> stateList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_state);

        // Initialize views
        initializeViews();
        
        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Set up submit button
        MaterialButton submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(v -> handleSubmit());

        // Set up RecyclerView
        setupRecyclerView();
    }

    private void initializeViews() {
        stateInput = findViewById(R.id.stateInput);
        statesRecyclerView = findViewById(R.id.statesRecyclerView);
    }

    private void setupRecyclerView() {
        stateList = new ArrayList<>();
        stateAdapter = new StateAdapter(stateList);
        statesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        statesRecyclerView.setAdapter(stateAdapter);
    }

    private void handleSubmit() {
        String stateName = stateInput.getText().toString().trim();
        if (stateName.isEmpty()) {
            Toast.makeText(this, "Please enter state name", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add new state to the list
        StateItem newState = new StateItem(stateName, "Active");
        stateList.add(newState);
        stateAdapter.notifyItemInserted(stateList.size() - 1);
        
        // Clear input
        stateInput.setText("");
    }

    // State Item class
    public static class StateItem {
        private String name;
        private String status;

        public StateItem(String name, String status) {
            this.name = name;
            this.status = status;
        }

        public String getName() {
            return name;
        }

        public String getStatus() {
            return status;
        }
    }

    // State Adapter class
    private class StateAdapter extends RecyclerView.Adapter<StateAdapter.StateViewHolder> {
        private List<StateItem> states;

        public StateAdapter(List<StateItem> states) {
            this.states = states;
        }

        @Override
        public StateViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = getLayoutInflater().inflate(R.layout.item_state, parent, false);
            return new StateViewHolder(view);
        }

        @Override
        public void onBindViewHolder(StateViewHolder holder, int position) {
            StateItem state = states.get(position);
            holder.nameText.setText(state.getName());
            holder.statusText.setText(state.getStatus());
            
            // Set up edit and delete buttons
            holder.editButton.setOnClickListener(v -> {
                // TODO: Implement edit functionality
                Toast.makeText(StateActivity.this, "Edit " + state.getName(), Toast.LENGTH_SHORT).show();
            });

            holder.deleteButton.setOnClickListener(v -> {
                // TODO: Implement delete functionality
                int pos = holder.getAdapterPosition();
                states.remove(pos);
                notifyItemRemoved(pos);
                Toast.makeText(StateActivity.this, "Deleted " + state.getName(), Toast.LENGTH_SHORT).show();
            });
        }

        @Override
        public int getItemCount() {
            return states.size();
        }

        class StateViewHolder extends RecyclerView.ViewHolder {
            TextView nameText;
            TextView statusText;
            ImageButton editButton;
            ImageButton deleteButton;

            StateViewHolder(android.view.View itemView) {
                super(itemView);
                nameText = itemView.findViewById(R.id.stateNameText);
                statusText = itemView.findViewById(R.id.stateStatusText);
                editButton = itemView.findViewById(R.id.editButton);
                deleteButton = itemView.findViewById(R.id.deleteButton);
            }
        }
    }
} 