package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class CallingStatusActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calling_status);

        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Initialize views
        TextInputEditText callingStatusInput = findViewById(R.id.callingStatusInput);
        MaterialButton submitButton = findViewById(R.id.submitButton);

        // Set up submit button click listener
        submitButton.setOnClickListener(v -> {
            String status = callingStatusInput.getText().toString();
            if (!status.isEmpty()) {
                // TODO: Implement submit functionality
                callingStatusInput.setText("");
            }
        });
    }
} 