package com.example.kfinoneapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class EmpDesignationActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DesignationAdapter adapter;
    private List<Designation> designationList;
    private AutoCompleteTextView departmentDropdown;
    private TextInputEditText designationNameInput;
    private MaterialButton submitButton;
    private String selectedDepartment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emp_designation);

        // Initialize views
        ImageButton backButton = findViewById(R.id.backButton);
        recyclerView = findViewById(R.id.designationRecyclerView);
        departmentDropdown = findViewById(R.id.departmentDropdown);
        designationNameInput = findViewById(R.id.designationNameInput);
        submitButton = findViewById(R.id.submitButton);

        // Setup back button
        backButton.setOnClickListener(v -> finish());

        // Setup department dropdown
        String[] departments = {"IT", "HR", "Finance", "Operations"};
        ArrayAdapter<String> departmentAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, departments);
        departmentDropdown.setAdapter(departmentAdapter);
        departmentDropdown.setOnItemClickListener((parent, view, position, id) -> {
            selectedDepartment = departments[position];
        });

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        designationList = new ArrayList<>();
        adapter = new DesignationAdapter(designationList);
        recyclerView.setAdapter(adapter);

        // Add sample data
        designationList.add(new Designation("Software Engineer", "IT", "Active"));
        designationList.add(new Designation("HR Manager", "HR", "Active"));
        designationList.add(new Designation("Financial Analyst", "Finance", "Inactive"));
        adapter.notifyDataSetChanged();

        // Setup submit button
        submitButton.setOnClickListener(v -> {
            String designationName = designationNameInput.getText().toString().trim();
            if (selectedDepartment == null) {
                Toast.makeText(this, "Please select a department", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!designationName.isEmpty()) {
                designationList.add(new Designation(designationName, selectedDepartment, "Active"));
                adapter.notifyItemInserted(designationList.size() - 1);
                designationNameInput.setText("");
                departmentDropdown.setText("");
                selectedDepartment = null;
                Toast.makeText(this, "Designation added successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please enter designation name", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private static class Designation {
        String name;
        String department;
        String status;

        Designation(String name, String department, String status) {
            this.name = name;
            this.department = department;
            this.status = status;
        }
    }

    private class DesignationAdapter extends RecyclerView.Adapter<DesignationAdapter.ViewHolder> {
        private List<Designation> designations;

        DesignationAdapter(List<Designation> designations) {
            this.designations = designations;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_designation, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Designation designation = designations.get(position);
            holder.nameText.setText(designation.name);
            holder.departmentText.setText(designation.department);
            holder.statusText.setText(designation.status);

            holder.editButton.setOnClickListener(v -> {
                // TODO: Implement edit functionality
                Toast.makeText(EmpDesignationActivity.this, "Edit clicked for " + designation.name, Toast.LENGTH_SHORT).show();
            });

            holder.deleteButton.setOnClickListener(v -> {
                // TODO: Implement delete functionality
                Toast.makeText(EmpDesignationActivity.this, "Delete clicked for " + designation.name, Toast.LENGTH_SHORT).show();
            });
        }

        @Override
        public int getItemCount() {
            return designations.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView nameText;
            TextView departmentText;
            TextView statusText;
            ImageButton editButton;
            ImageButton deleteButton;

            ViewHolder(View itemView) {
                super(itemView);
                nameText = itemView.findViewById(R.id.nameText);
                departmentText = itemView.findViewById(R.id.departmentText);
                statusText = itemView.findViewById(R.id.statusText);
                editButton = itemView.findViewById(R.id.editButton);
                deleteButton = itemView.findViewById(R.id.deleteButton);
            }
        }
    }
} 