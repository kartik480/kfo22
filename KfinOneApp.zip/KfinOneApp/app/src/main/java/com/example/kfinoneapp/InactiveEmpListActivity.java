package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class InactiveEmpListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EmployeeAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inactive_emp_list);

        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create sample data
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("John Doe", "EMP001", "1234567890", "john@example.com", "Inactive"));
        employees.add(new Employee("Jane Smith", "EMP002", "9876543210", "jane@example.com", "Inactive"));
        employees.add(new Employee("Mike Johnson", "EMP003", "5555555555", "mike@example.com", "Inactive"));

        // Set up adapter
        adapter = new EmployeeAdapter(employees);
        recyclerView.setAdapter(adapter);
    }

    // Employee data class
    private static class Employee {
        String fullName;
        String empId;
        String mobile;
        String email;
        String status;

        Employee(String fullName, String empId, String mobile, String email, String status) {
            this.fullName = fullName;
            this.empId = empId;
            this.mobile = mobile;
            this.email = email;
            this.status = status;
        }
    }

    // Adapter class
    private class EmployeeAdapter extends RecyclerView.Adapter<EmployeeAdapter.ViewHolder> {
        private List<Employee> employees;

        EmployeeAdapter(List<Employee> employees) {
            this.employees = employees;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = getLayoutInflater().inflate(R.layout.item_user_table, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Employee employee = employees.get(position);
            holder.fullNameText.setText(employee.fullName);
            holder.empIdText.setText(employee.empId);
            holder.mobileText.setText(employee.mobile);
            holder.emailText.setText(employee.email);
            holder.statusText.setText(employee.status);
        }

        @Override
        public int getItemCount() {
            return employees.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView fullNameText;
            TextView empIdText;
            TextView mobileText;
            TextView emailText;
            TextView statusText;
            ImageButton editButton;
            ImageButton deleteButton;

            ViewHolder(android.view.View itemView) {
                super(itemView);
                fullNameText = itemView.findViewById(R.id.fullNameText);
                empIdText = itemView.findViewById(R.id.empIdText);
                mobileText = itemView.findViewById(R.id.mobileText);
                emailText = itemView.findViewById(R.id.emailText);
                statusText = itemView.findViewById(R.id.statusText);
                editButton = itemView.findViewById(R.id.editButton);
                deleteButton = itemView.findViewById(R.id.deleteButton);

                editButton.setOnClickListener(v -> {
                    // TODO: Implement edit functionality
                });

                deleteButton.setOnClickListener(v -> {
                    // TODO: Implement delete functionality
                });
            }
        }
    }
} 