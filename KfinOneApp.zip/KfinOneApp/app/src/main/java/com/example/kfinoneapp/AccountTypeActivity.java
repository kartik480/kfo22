package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class AccountTypeActivity extends AppCompatActivity {
    private TextInputEditText accountTypeInput;
    private MaterialButton submitButton;
    private RecyclerView accountTypesRecyclerView;
    private AccountTypeAdapter accountTypeAdapter;
    private List<AccountTypeItem> accountTypesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_type);

        // Initialize views
        initializeViews();
        
        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Set up submit button
        submitButton.setOnClickListener(v -> handleSubmit());

        // Set up RecyclerView
        setupRecyclerView();
    }

    private void initializeViews() {
        accountTypeInput = findViewById(R.id.accountTypeInput);
        submitButton = findViewById(R.id.submitButton);
        accountTypesRecyclerView = findViewById(R.id.accountTypesRecyclerView);
    }

    private void setupRecyclerView() {
        accountTypesList = new ArrayList<>();
        accountTypeAdapter = new AccountTypeAdapter(accountTypesList);
        accountTypesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        accountTypesRecyclerView.setAdapter(accountTypeAdapter);
    }

    private void handleSubmit() {
        String accountType = accountTypeInput.getText().toString().trim();
        if (!accountType.isEmpty()) {
            AccountTypeItem newAccountType = new AccountTypeItem(accountType, "Active");
            accountTypesList.add(newAccountType);
            accountTypeAdapter.notifyItemInserted(accountTypesList.size() - 1);
            accountTypeInput.setText("");
        }
    }
} 