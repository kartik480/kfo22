package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class CallingSubStatusActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calling_sub_status);

        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Initialize views
        AutoCompleteTextView callingStatusDropdown = findViewById(R.id.callingStatusDropdown);
        TextInputEditText callingSubStatusInput = findViewById(R.id.callingSubStatusInput);
        MaterialButton submitButton = findViewById(R.id.submitButton);

        // Set up dropdown adapter
        String[] callingStatuses = {"Status 1", "Status 2", "Status 3"}; // TODO: Replace with actual data
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, callingStatuses);
        callingStatusDropdown.setAdapter(adapter);

        // Set up submit button click listener
        submitButton.setOnClickListener(v -> {
            String status = callingStatusDropdown.getText().toString();
            String subStatus = callingSubStatusInput.getText().toString();
            if (!status.isEmpty() && !subStatus.isEmpty()) {
                // TODO: Implement submit functionality
                callingStatusDropdown.setText("");
                callingSubStatusInput.setText("");
            }
        });
    }
} 