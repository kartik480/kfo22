package com.example.kfinoneapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;

public class EmpMasterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emp_master);

        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Initialize card views
        MaterialCardView addEmpCard = findViewById(R.id.addEmpCard);
        MaterialCardView activeEmpListCard = findViewById(R.id.activeEmpListCard);
        MaterialCardView inactiveEmpListCard = findViewById(R.id.inactiveEmpListCard);
        MaterialCardView empDepartmentCard = findViewById(R.id.empDepartmentCard);
        MaterialCardView empDesignationCard = findViewById(R.id.empDesignationCard);

        // Set click listeners
        addEmpCard.setOnClickListener(v -> {
            Intent intent = new Intent(EmpMasterActivity.this, AddEmpDetailsActivity.class);
            startActivity(intent);
        });

        activeEmpListCard.setOnClickListener(v -> {
            Intent intent = new Intent(EmpMasterActivity.this, ActiveEmpListActivity.class);
            startActivity(intent);
        });

        inactiveEmpListCard.setOnClickListener(v -> {
            Intent intent = new Intent(EmpMasterActivity.this, InactiveEmpListActivity.class);
            startActivity(intent);
        });

        empDepartmentCard.setOnClickListener(v -> {
            Intent intent = new Intent(EmpMasterActivity.this, EmpDepartmentActivity.class);
            startActivity(intent);
        });

        empDesignationCard.setOnClickListener(v -> {
            Intent intent = new Intent(EmpMasterActivity.this, EmpDesignationActivity.class);
            startActivity(intent);
        });
    }
} 