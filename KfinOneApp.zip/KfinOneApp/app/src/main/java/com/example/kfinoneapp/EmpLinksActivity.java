package com.example.kfinoneapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.kfinoneapp.databinding.ActivityEmpLinksBinding;
import com.google.android.material.card.MaterialCardView;

public class EmpLinksActivity extends AppCompatActivity {
    private ActivityEmpLinksBinding binding;
    private MaterialCardView empManageCard;
    private MaterialCardView empDataCard;
    private MaterialCardView empWorkCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEmpLinksBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize views
        empManageCard = binding.empManageCard;
        empDataCard = binding.empDataCard;
        empWorkCard = binding.empWorkCard;

        // Set click listeners
        empManageCard.setOnClickListener(v -> {
            Intent intent = new Intent(EmpLinksActivity.this, EmpManageActivity.class);
            startActivity(intent);
        });

        empDataCard.setOnClickListener(v -> {
            Intent intent = new Intent(EmpLinksActivity.this, EmpDataActivity.class);
            startActivity(intent);
        });

        empWorkCard.setOnClickListener(v -> {
            Intent intent = new Intent(EmpLinksActivity.this, EmpWorkActivity.class);
            startActivity(intent);
        });

        // Set back button click listener
        binding.backButton.setOnClickListener(v -> finish());
    }
} 