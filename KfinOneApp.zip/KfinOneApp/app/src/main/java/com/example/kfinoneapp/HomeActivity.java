package com.example.kfinoneapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.navigation.NavigationView;

public class HomeActivity extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private ScrollView mainScrollView;
    private LinearLayout mainContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize toolbar
        Toolbar toolbar = findViewById(R.id.topToolbar);
        setSupportActionBar(toolbar);

        // Initialize drawer layout
        drawerLayout = findViewById(R.id.drawer_layout);

        // Set up menu button
        ImageButton menuButton = findViewById(R.id.menuButton);
        menuButton.setOnClickListener(v -> drawerLayout.open());

        // Set up navigation drawer
        NavigationView navigationView = findViewById(R.id.navigationView);
        navigationView.setNavigationItemSelectedListener(this::onNavigationItemSelected);

        // Set up help button
        ImageButton helpButton = findViewById(R.id.helpButton);
        helpButton.setOnClickListener(v -> {
            // TODO: Implement help functionality
        });

        // Set up account button
        ImageButton accountButton = findViewById(R.id.accountButton);
        accountButton.setOnClickListener(v -> {
            // TODO: Implement account functionality
        });

        // Initialize main content views
        mainScrollView = findViewById(R.id.mainScrollView);
        mainContent = findViewById(R.id.mainContent);

        // Set up bottom navigation
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            return onBottomNavigationItemSelected(id);
        });

        // Set up click listeners for the boxes
        MaterialCardView empMasterCard = findViewById(R.id.empMasterCard);
        empMasterCard.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, EmpMasterActivity.class);
            startActivity(intent);
        });

        MaterialCardView locationMasterCard = findViewById(R.id.locationMasterCard);
        locationMasterCard.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, LocationMasterActivity.class);
            startActivity(intent);
        });

        MaterialCardView sdsaMasterCard = findViewById(R.id.sdsaMasterCard);
        sdsaMasterCard.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, SdsaMasterActivity.class);
            startActivity(intent);
        });

        MaterialCardView dsaCodeMasterCard = findViewById(R.id.dsaCodeMasterCard);
        dsaCodeMasterCard.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, DsaCodeMasterActivity.class);
            startActivity(intent);
        });

        MaterialCardView bankMasterCard = findViewById(R.id.bankMasterCard);
        bankMasterCard.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, BankMasterActivity.class);
            startActivity(intent);
        });

        MaterialCardView empLinksCard = findViewById(R.id.empLinksCard);
        empLinksCard.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, EmpLinksActivity.class);
            startActivity(intent);
        });

        MaterialCardView agentMasterCard = findViewById(R.id.agentMasterCard);
        agentMasterCard.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, AgentMasterActivity.class);
            startActivity(intent);
        });

        MaterialCardView dsaNameCard = findViewById(R.id.dsaNameCard);
        dsaNameCard.setOnClickListener(v -> {
            // TODO: Implement DSA name functionality
        });

        MaterialCardView typeOfLoansCard = findViewById(R.id.typeOfLoansCard);
        typeOfLoansCard.setOnClickListener(v -> {
            // TODO: Implement type of loans functionality
        });

        MaterialCardView bankersCard = findViewById(R.id.bankersCardHorizontal);
        bankersCard.setOnClickListener(v -> {
            // TODO: Implement bankers functionality
        });

        MaterialCardView partnerMasterCard = findViewById(R.id.partnerMasterCard);
        partnerMasterCard.setOnClickListener(v -> {
            // TODO: Implement partner master functionality
        });

        MaterialCardView payoutCard = findViewById(R.id.payoutCard);
        payoutCard.setOnClickListener(v -> {
            // TODO: Implement payout functionality
        });
    }

    private boolean onBottomNavigationItemSelected(int id) {
        if (id == R.id.navigation_home) {
            mainScrollView.setVisibility(View.VISIBLE);
            return true;
        } else if (id == R.id.navigation_files) {
            // TODO: Implement files section
            return true;
        } else if (id == R.id.navigation_agents) {
            // TODO: Implement agents section
            return true;
        } else if (id == R.id.navigation_more) {
            mainScrollView.setVisibility(View.GONE);
            return true;
        }
        return false;
    }

    private boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_dashboard) {
            // TODO: Implement dashboard
            return true;
        } else if (id == R.id.nav_profile) {
            // TODO: Implement profile
            return true;
        } else if (id == R.id.nav_settings) {
            // TODO: Implement settings
            return true;
        } else if (id == R.id.nav_calculator) {
            // TODO: Implement calculator
            return true;
        } else if (id == R.id.nav_calendar) {
            // TODO: Implement calendar
            return true;
        } else if (id == R.id.nav_notifications) {
            // TODO: Implement notifications
            return true;
        } else if (id == R.id.nav_help) {
            // TODO: Implement help
            return true;
        } else if (id == R.id.nav_feedback) {
            // TODO: Implement feedback
            return true;
        } else if (id == R.id.nav_about) {
            // TODO: Implement about
            return true;
        } else if (id == R.id.nav_emp_master) {
            Intent intent = new Intent(HomeActivity.this, EmpMasterActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.nav_location_master) {
            // TODO: Implement location master
            return true;
        } else if (id == R.id.nav_sdsa_master) {
            // TODO: Implement SDSA master
            return true;
        }
        return false;
    }
} 