package com.example.kfinoneapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ActiveSdsaListActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private SdsaAdapter adapter;
    private List<SdsaItem> sdsaList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_active_sdsa_list);

        // Initialize back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.sdsaListRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize data
        sdsaList = new ArrayList<>();
        // Add sample data
        sdsaList.add(new SdsaItem("John Doe", "1234567890", "john@example.com", "password123", "Active"));
        sdsaList.add(new SdsaItem("Jane Smith", "9876543210", "jane@example.com", "password456", "Active"));

        // Set adapter
        adapter = new SdsaAdapter(sdsaList);
        recyclerView.setAdapter(adapter);
    }

    // SDSA Item class
    public static class SdsaItem {
        private String fullname;
        private String phone;
        private String email;
        private String password;
        private String status;

        public SdsaItem(String fullname, String phone, String email, String password, String status) {
            this.fullname = fullname;
            this.phone = phone;
            this.email = email;
            this.password = password;
            this.status = status;
        }

        // Getters
        public String getFullname() { return fullname; }
        public String getPhone() { return phone; }
        public String getEmail() { return email; }
        public String getPassword() { return password; }
        public String getStatus() { return status; }
    }

    // Adapter class
    private class SdsaAdapter extends RecyclerView.Adapter<SdsaAdapter.ViewHolder> {
        private List<SdsaItem> items;

        public SdsaAdapter(List<SdsaItem> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_sdsa, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            SdsaItem item = items.get(position);
            holder.fullnameText.setText(item.getFullname());
            holder.phoneText.setText(item.getPhone());
            holder.emailText.setText(item.getEmail());
            holder.passwordText.setText(item.getPassword());
            holder.statusText.setText(item.getStatus());

            holder.editButton.setOnClickListener(v -> {
                // TODO: Implement edit functionality
                Toast.makeText(ActiveSdsaListActivity.this, "Edit clicked for " + item.getFullname(), Toast.LENGTH_SHORT).show();
            });

            holder.deleteButton.setOnClickListener(v -> {
                // TODO: Implement delete functionality
                Toast.makeText(ActiveSdsaListActivity.this, "Delete clicked for " + item.getFullname(), Toast.LENGTH_SHORT).show();
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView fullnameText, phoneText, emailText, passwordText, statusText;
            ImageButton editButton, deleteButton;

            public ViewHolder(View itemView) {
                super(itemView);
                fullnameText = itemView.findViewById(R.id.fullnameText);
                phoneText = itemView.findViewById(R.id.phoneText);
                emailText = itemView.findViewById(R.id.emailText);
                passwordText = itemView.findViewById(R.id.passwordText);
                statusText = itemView.findViewById(R.id.statusText);
                editButton = itemView.findViewById(R.id.editButton);
                deleteButton = itemView.findViewById(R.id.deleteButton);
            }
        }
    }
} 