package com.example.kfinoneapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class InactiveSdsaListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private InactiveSdsaAdapter adapter;
    private List<InactiveSdsaItem> sdsaList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inactive_sdsa_list);

        // Initialize back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.inactiveSdsaListRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize data
        sdsaList = new ArrayList<>();
        // Add sample data
        sdsaList.add(new InactiveSdsaItem("John Doe", "1234567890", "john@example.com", "Inactive"));
        sdsaList.add(new InactiveSdsaItem("Jane Smith", "9876543210", "jane@example.com", "Inactive"));

        // Set adapter
        adapter = new InactiveSdsaAdapter(sdsaList);
        recyclerView.setAdapter(adapter);
    }

    private static class InactiveSdsaItem {
        String fullname;
        String mobile;
        String email;
        String status;

        InactiveSdsaItem(String fullname, String mobile, String email, String status) {
            this.fullname = fullname;
            this.mobile = mobile;
            this.email = email;
            this.status = status;
        }
    }

    private class InactiveSdsaAdapter extends RecyclerView.Adapter<InactiveSdsaAdapter.ViewHolder> {
        private List<InactiveSdsaItem> items;

        InactiveSdsaAdapter(List<InactiveSdsaItem> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_inactive_sdsa, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            InactiveSdsaItem item = items.get(position);
            holder.fullnameText.setText(item.fullname);
            holder.mobileText.setText(item.mobile);
            holder.emailText.setText(item.email);
            holder.statusText.setText(item.status);
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView fullnameText, mobileText, emailText, statusText;

            ViewHolder(View view) {
                super(view);
                fullnameText = view.findViewById(R.id.fullnameText);
                mobileText = view.findViewById(R.id.mobileText);
                emailText = view.findViewById(R.id.emailText);
                statusText = view.findViewById(R.id.statusText);
            }
        }
    }
} 