package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class BankersDesignationActivity extends AppCompatActivity {
    private TextInputEditText designationInput;
    private MaterialButton submitButton;
    private RecyclerView designationsRecyclerView;
    private BankersDesignationAdapter designationAdapter;
    private List<BankersDesignationItem> designationsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bankers_designation);

        // Initialize views
        initializeViews();
        
        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Set up submit button
        submitButton.setOnClickListener(v -> handleSubmit());

        // Set up RecyclerView
        setupRecyclerView();
    }

    private void initializeViews() {
        designationInput = findViewById(R.id.designationInput);
        submitButton = findViewById(R.id.submitButton);
        designationsRecyclerView = findViewById(R.id.designationsRecyclerView);
    }

    private void setupRecyclerView() {
        designationsList = new ArrayList<>();
        designationAdapter = new BankersDesignationAdapter(designationsList);
        designationsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        designationsRecyclerView.setAdapter(designationAdapter);
    }

    private void handleSubmit() {
        String designation = designationInput.getText().toString().trim();
        if (!designation.isEmpty()) {
            BankersDesignationItem newDesignation = new BankersDesignationItem(designation, "Active");
            designationsList.add(newDesignation);
            designationAdapter.notifyItemInserted(designationsList.size() - 1);
            designationInput.setText("");
        }
    }
} 