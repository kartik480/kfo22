package com.example.kfinoneapp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class AddSdsaActivity extends AppCompatActivity {
    private TextInputEditText emailInput, passwordInput, firstNameInput, lastNameInput, aliasNameInput,
            phoneInput, altPhoneInput, companyNameInput, officeAddressInput, residentialAddressInput,
            aadharInput, panInput, accountNumberInput, ifscInput;
    private AutoCompleteTextView branchStateDropdown, branchLocationDropdown, bankNameDropdown,
            accountTypeDropdown, reportingToDropdown;
    private MaterialButton panUploadButton, aadharUploadButton, photoUploadButton,
            bankProofUploadButton, companyLogoUploadButton, submitButton;
    private ImageButton backButton;

    private ActivityResultLauncher<Intent> documentPickerLauncher;
    private Uri selectedDocumentUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_sdsa);

        initializeViews();
        setupDropdowns();
        setupDocumentPicker();
        setupClickListeners();
    }

    private void initializeViews() {
        // Initialize all input fields
        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        firstNameInput = findViewById(R.id.firstNameInput);
        lastNameInput = findViewById(R.id.lastNameInput);
        aliasNameInput = findViewById(R.id.aliasNameInput);
        phoneInput = findViewById(R.id.phoneInput);
        altPhoneInput = findViewById(R.id.altPhoneInput);
        companyNameInput = findViewById(R.id.companyNameInput);
        officeAddressInput = findViewById(R.id.officeAddressInput);
        residentialAddressInput = findViewById(R.id.residentialAddressInput);
        aadharInput = findViewById(R.id.aadharInput);
        panInput = findViewById(R.id.panInput);
        accountNumberInput = findViewById(R.id.accountNumberInput);
        ifscInput = findViewById(R.id.ifscInput);

        // Initialize dropdowns
        branchStateDropdown = findViewById(R.id.branchStateDropdown);
        branchLocationDropdown = findViewById(R.id.branchLocationDropdown);
        bankNameDropdown = findViewById(R.id.bankNameDropdown);
        accountTypeDropdown = findViewById(R.id.accountTypeDropdown);
        reportingToDropdown = findViewById(R.id.reportingToDropdown);

        // Initialize buttons
        panUploadButton = findViewById(R.id.panUploadButton);
        aadharUploadButton = findViewById(R.id.aadharUploadButton);
        photoUploadButton = findViewById(R.id.photoUploadButton);
        bankProofUploadButton = findViewById(R.id.bankProofUploadButton);
        companyLogoUploadButton = findViewById(R.id.companyLogoUploadButton);
        submitButton = findViewById(R.id.submitButton);
        backButton = findViewById(R.id.backButton);
    }

    private void setupDropdowns() {
        // Branch States
        List<String> branchStates = new ArrayList<>();
        branchStates.add("Maharashtra");
        branchStates.add("Karnataka");
        branchStates.add("Tamil Nadu");
        branchStates.add("Gujarat");
        branchStates.add("Delhi");
        ArrayAdapter<String> branchStateAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, branchStates);
        branchStateDropdown.setAdapter(branchStateAdapter);

        // Branch Locations
        List<String> branchLocations = new ArrayList<>();
        branchLocations.add("Mumbai");
        branchLocations.add("Bangalore");
        branchLocations.add("Chennai");
        branchLocations.add("Ahmedabad");
        branchLocations.add("New Delhi");
        ArrayAdapter<String> branchLocationAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, branchLocations);
        branchLocationDropdown.setAdapter(branchLocationAdapter);

        // Bank Names
        List<String> bankNames = new ArrayList<>();
        bankNames.add("State Bank of India");
        bankNames.add("HDFC Bank");
        bankNames.add("ICICI Bank");
        bankNames.add("Axis Bank");
        bankNames.add("Punjab National Bank");
        ArrayAdapter<String> bankNameAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, bankNames);
        bankNameDropdown.setAdapter(bankNameAdapter);

        // Account Types
        List<String> accountTypes = new ArrayList<>();
        accountTypes.add("Savings Account");
        accountTypes.add("Current Account");
        accountTypes.add("Fixed Deposit");
        ArrayAdapter<String> accountTypeAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, accountTypes);
        accountTypeDropdown.setAdapter(accountTypeAdapter);

        // Reporting To
        List<String> reportingToList = new ArrayList<>();
        reportingToList.add("Manager 1");
        reportingToList.add("Manager 2");
        reportingToList.add("Manager 3");
        ArrayAdapter<String> reportingToAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, reportingToList);
        reportingToDropdown.setAdapter(reportingToAdapter);
    }

    private void setupDocumentPicker() {
        documentPickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null) {
                        selectedDocumentUri = data.getData();
                        // Handle the selected document
                        Toast.makeText(this, "Document selected successfully", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        );
    }

    private void setupClickListeners() {
        // Back button
        backButton.setOnClickListener(v -> finish());

        // Document upload buttons
        panUploadButton.setOnClickListener(v -> openDocumentPicker("PAN Card"));
        aadharUploadButton.setOnClickListener(v -> openDocumentPicker("Aadhar Card"));
        photoUploadButton.setOnClickListener(v -> openDocumentPicker("Photo"));
        bankProofUploadButton.setOnClickListener(v -> openDocumentPicker("Bank Proof"));
        companyLogoUploadButton.setOnClickListener(v -> openDocumentPicker("Company Logo"));

        // Submit button
        submitButton.setOnClickListener(v -> {
            if (validateInputs()) {
                // TODO: Implement form submission
                Toast.makeText(this, "Form submitted successfully", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private void openDocumentPicker(String documentType) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        documentPickerLauncher.launch(intent);
    }

    private boolean validateInputs() {
        // Validate all required fields
        if (emailInput.getText().toString().trim().isEmpty()) {
            emailInput.setError("Email is required");
            return false;
        }
        if (passwordInput.getText().toString().trim().isEmpty()) {
            passwordInput.setError("Password is required");
            return false;
        }
        if (firstNameInput.getText().toString().trim().isEmpty()) {
            firstNameInput.setError("First name is required");
            return false;
        }
        if (lastNameInput.getText().toString().trim().isEmpty()) {
            lastNameInput.setError("Last name is required");
            return false;
        }
        if (phoneInput.getText().toString().trim().isEmpty()) {
            phoneInput.setError("Phone number is required");
            return false;
        }
        if (companyNameInput.getText().toString().trim().isEmpty()) {
            companyNameInput.setError("Company name is required");
            return false;
        }
        if (branchStateDropdown.getText().toString().trim().isEmpty()) {
            branchStateDropdown.setError("Branch state is required");
            return false;
        }
        if (branchLocationDropdown.getText().toString().trim().isEmpty()) {
            branchLocationDropdown.setError("Branch location is required");
            return false;
        }
        if (aadharInput.getText().toString().trim().isEmpty()) {
            aadharInput.setError("Aadhar number is required");
            return false;
        }
        if (panInput.getText().toString().trim().isEmpty()) {
            panInput.setError("PAN number is required");
            return false;
        }
        if (accountNumberInput.getText().toString().trim().isEmpty()) {
            accountNumberInput.setError("Account number is required");
            return false;
        }
        if (ifscInput.getText().toString().trim().isEmpty()) {
            ifscInput.setError("IFSC code is required");
            return false;
        }
        if (bankNameDropdown.getText().toString().trim().isEmpty()) {
            bankNameDropdown.setError("Bank name is required");
            return false;
        }
        if (accountTypeDropdown.getText().toString().trim().isEmpty()) {
            accountTypeDropdown.setError("Account type is required");
            return false;
        }
        if (reportingToDropdown.getText().toString().trim().isEmpty()) {
            reportingToDropdown.setError("Reporting to is required");
            return false;
        }

        return true;
    }
} 