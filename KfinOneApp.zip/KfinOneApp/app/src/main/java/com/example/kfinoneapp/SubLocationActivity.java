package com.example.kfinoneapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class SubLocationActivity extends AppCompatActivity {
    private AutoCompleteTextView stateDropdown;
    private AutoCompleteTextView locationDropdown;
    private TextInputEditText subLocationInput;
    private MaterialButton submitButton;
    private RecyclerView subLocationsRecyclerView;
    private SubLocationAdapter subLocationAdapter;
    private List<SubLocation> subLocations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_location);

        // Initialize views
        stateDropdown = findViewById(R.id.stateDropdown);
        locationDropdown = findViewById(R.id.locationDropdown);
        subLocationInput = findViewById(R.id.subLocationInput);
        submitButton = findViewById(R.id.submitButton);
        subLocationsRecyclerView = findViewById(R.id.subLocationsRecyclerView);

        // Setup back button
        findViewById(R.id.backButton).setOnClickListener(v -> finish());

        // Setup state dropdown
        String[] states = {"Maharashtra", "Karnataka", "Tamil Nadu", "Gujarat"}; // Example states
        ArrayAdapter<String> stateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, states);
        stateDropdown.setAdapter(stateAdapter);

        // Setup location dropdown
        String[] locations = {"Mumbai", "Bangalore", "Chennai", "Ahmedabad"}; // Example locations
        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, locations);
        locationDropdown.setAdapter(locationAdapter);

        // Setup RecyclerView
        subLocations = new ArrayList<>();
        subLocationAdapter = new SubLocationAdapter(subLocations);
        subLocationsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        subLocationsRecyclerView.setAdapter(subLocationAdapter);

        // Add some sample data
        subLocations.add(new SubLocation("Andheri", "Maharashtra", "Mumbai", "Active"));
        subLocations.add(new SubLocation("Koramangala", "Karnataka", "Bangalore", "Active"));
        subLocationAdapter.notifyDataSetChanged();

        // Setup submit button
        submitButton.setOnClickListener(v -> {
            String selectedState = stateDropdown.getText().toString();
            String selectedLocation = locationDropdown.getText().toString();
            String subLocationName = subLocationInput.getText().toString();

            if (selectedState.isEmpty() || selectedLocation.isEmpty() || subLocationName.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Add new sub-location
            subLocations.add(new SubLocation(subLocationName, selectedState, selectedLocation, "Active"));
            subLocationAdapter.notifyItemInserted(subLocations.size() - 1);

            // Clear inputs
            stateDropdown.setText("");
            locationDropdown.setText("");
            subLocationInput.setText("");
        });
    }

    // SubLocation data class
    private static class SubLocation {
        String name;
        String state;
        String location;
        String status;

        SubLocation(String name, String state, String location, String status) {
            this.name = name;
            this.state = state;
            this.location = location;
            this.status = status;
        }
    }

    // RecyclerView Adapter
    private class SubLocationAdapter extends RecyclerView.Adapter<SubLocationAdapter.SubLocationViewHolder> {
        private List<SubLocation> subLocations;

        SubLocationAdapter(List<SubLocation> subLocations) {
            this.subLocations = subLocations;
        }

        @Override
        public SubLocationViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            View view = getLayoutInflater().inflate(R.layout.item_sub_location, parent, false);
            return new SubLocationViewHolder(view);
        }

        @Override
        public void onBindViewHolder(SubLocationViewHolder holder, int position) {
            SubLocation subLocation = subLocations.get(position);
            holder.subLocationName.setText(subLocation.name);
            holder.stateName.setText(subLocation.state);
            holder.locationName.setText(subLocation.location);
            holder.status.setText(subLocation.status);

            holder.editButton.setOnClickListener(v -> {
                // TODO: Implement edit functionality
                Toast.makeText(SubLocationActivity.this, "Edit clicked for " + subLocation.name, Toast.LENGTH_SHORT).show();
            });

            holder.deleteButton.setOnClickListener(v -> {
                subLocations.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, subLocations.size());
            });
        }

        @Override
        public int getItemCount() {
            return subLocations.size();
        }

        class SubLocationViewHolder extends RecyclerView.ViewHolder {
            TextView subLocationName;
            TextView stateName;
            TextView locationName;
            TextView status;
            ImageButton editButton;
            ImageButton deleteButton;

            SubLocationViewHolder(View itemView) {
                super(itemView);
                subLocationName = itemView.findViewById(R.id.subLocationName);
                stateName = itemView.findViewById(R.id.stateName);
                locationName = itemView.findViewById(R.id.locationName);
                status = itemView.findViewById(R.id.status);
                editButton = itemView.findViewById(R.id.editButton);
                deleteButton = itemView.findViewById(R.id.deleteButton);
            }
        }
    }
} 