package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class AddAgentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_agent);

        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Initialize views
        TextInputEditText phoneNumberInput = findViewById(R.id.phoneNumberInput);
        TextInputEditText fullNameInput = findViewById(R.id.fullNameInput);
        TextInputEditText companyNameInput = findViewById(R.id.companyNameInput);
        TextInputEditText alternativePhoneInput = findViewById(R.id.alternativePhoneInput);
        TextInputEditText emailInput = findViewById(R.id.emailInput);
        AutoCompleteTextView partnerTypeDropdown = findViewById(R.id.partnerTypeDropdown);
        AutoCompleteTextView branchStateDropdown = findViewById(R.id.branchStateDropdown);
        AutoCompleteTextView branchLocationDropdown = findViewById(R.id.branchLocationDropdown);
        TextInputEditText addressInput = findViewById(R.id.addressInput);
        MaterialButton uploadVisitingCardButton = findViewById(R.id.uploadVisitingCardButton);
        MaterialButton submitButton = findViewById(R.id.submitButton);

        // Set up dropdown adapters
        String[] partnerTypes = {"Type 1", "Type 2", "Type 3"}; // TODO: Replace with actual data
        String[] branchStates = {"State 1", "State 2", "State 3"}; // TODO: Replace with actual data
        String[] branchLocations = {"Location 1", "Location 2", "Location 3"}; // TODO: Replace with actual data

        ArrayAdapter<String> partnerTypeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, partnerTypes);
        ArrayAdapter<String> branchStateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, branchStates);
        ArrayAdapter<String> branchLocationAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, branchLocations);

        partnerTypeDropdown.setAdapter(partnerTypeAdapter);
        branchStateDropdown.setAdapter(branchStateAdapter);
        branchLocationDropdown.setAdapter(branchLocationAdapter);

        // Set up visiting card upload button click listener
        uploadVisitingCardButton.setOnClickListener(v -> {
            // TODO: Implement file picker functionality
        });

        // Set up submit button click listener
        submitButton.setOnClickListener(v -> {
            // TODO: Implement form validation and submission
            String phoneNumber = phoneNumberInput.getText().toString();
            String fullName = fullNameInput.getText().toString();
            String companyName = companyNameInput.getText().toString();
            String alternativePhone = alternativePhoneInput.getText().toString();
            String email = emailInput.getText().toString();
            String partnerType = partnerTypeDropdown.getText().toString();
            String branchState = branchStateDropdown.getText().toString();
            String branchLocation = branchLocationDropdown.getText().toString();
            String address = addressInput.getText().toString();

            if (!phoneNumber.isEmpty() && !fullName.isEmpty() && !companyName.isEmpty() && !email.isEmpty() 
                && !partnerType.isEmpty() && !branchState.isEmpty() && !branchLocation.isEmpty() && !address.isEmpty()) {
                // TODO: Implement submit functionality
                clearForm();
            }
        });
    }

    private void clearForm() {
        // TODO: Clear all input fields after successful submission
    }
} 