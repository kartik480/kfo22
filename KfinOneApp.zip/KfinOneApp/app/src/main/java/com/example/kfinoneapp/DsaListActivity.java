package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.kfinoneapp.databinding.ActivityDsaListBinding;

public class DsaListActivity extends AppCompatActivity {
    private ActivityDsaListBinding binding;
    private AutoCompleteTextView vendorBankSpinner;
    private AutoCompleteTextView loanTypeSpinner;
    private AutoCompleteTextView stateSpinner;
    private AutoCompleteTextView locationSpinner;
    private TextView vendorBankValue;
    private TextView dsaCodeValue;
    private TextView dsaNameValue;
    private TextView loanTypeValue;
    private TextView stateValue;
    private TextView locationValue;
    private Button editButton;
    private Button deleteButton;
    private TextView backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDsaListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initializeViews();
        setupDropdowns();
        setupButtons();
    }

    private void initializeViews() {
        vendorBankSpinner = binding.vendorBankSpinner;
        loanTypeSpinner = binding.loanTypeSpinner;
        stateSpinner = binding.stateSpinner;
        locationSpinner = binding.locationSpinner;
        
        vendorBankValue = binding.vendorBankValue;
        dsaCodeValue = binding.dsaCodeValue;
        dsaNameValue = binding.dsaNameValue;
        loanTypeValue = binding.loanTypeValue;
        stateValue = binding.stateValue;
        locationValue = binding.locationValue;
        
        editButton = binding.editButton;
        deleteButton = binding.deleteButton;
        backButton = binding.backButton;
    }

    private void setupDropdowns() {
        // Sample data for dropdowns
        String[] vendorBanks = {"Select Vendor Bank", "Bank A", "Bank B", "Bank C"};
        String[] loanTypes = {"Select Loan Type", "Personal Loan", "Home Loan", "Business Loan"};
        String[] states = {"Select State", "Maharashtra", "Karnataka", "Tamil Nadu"};
        String[] locations = {"Select Location", "Mumbai", "Bangalore", "Chennai"};

        ArrayAdapter<String> vendorBankAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, vendorBanks);
        ArrayAdapter<String> loanTypeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, loanTypes);
        ArrayAdapter<String> stateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, states);
        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, locations);

        vendorBankAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        loanTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        stateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        vendorBankSpinner.setAdapter(vendorBankAdapter);
        loanTypeSpinner.setAdapter(loanTypeAdapter);
        stateSpinner.setAdapter(stateAdapter);
        locationSpinner.setAdapter(locationAdapter);
    }

    private void setupButtons() {
        backButton.setOnClickListener(v -> finish());

        binding.filterButton.setOnClickListener(v -> {
            // TODO: Implement filter functionality
            // For now, just set some sample data
            vendorBankValue.setText(vendorBankSpinner.getText().toString());
            dsaCodeValue.setText("DSA001");
            dsaNameValue.setText("Sample DSA");
            loanTypeValue.setText(loanTypeSpinner.getText().toString());
            stateValue.setText(stateSpinner.getText().toString());
            locationValue.setText(locationSpinner.getText().toString());
        });

        binding.resetButton.setOnClickListener(v -> {
            vendorBankSpinner.setText("");
            loanTypeSpinner.setText("");
            stateSpinner.setText("");
            locationSpinner.setText("");
            // Clear the values in the table
            vendorBankValue.setText("");
            dsaCodeValue.setText("");
            dsaNameValue.setText("");
            loanTypeValue.setText("");
            stateValue.setText("");
            locationValue.setText("");
        });

        editButton.setOnClickListener(v -> {
            // TODO: Implement edit functionality
        });

        deleteButton.setOnClickListener(v -> {
            // TODO: Implement delete functionality
        });
    }
} 