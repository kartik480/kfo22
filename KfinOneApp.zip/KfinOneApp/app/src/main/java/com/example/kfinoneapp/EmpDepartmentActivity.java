package com.example.kfinoneapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class EmpDepartmentActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DepartmentAdapter adapter;
    private List<Department> departmentList;
    private TextInputEditText departmentNameInput;
    private MaterialButton submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emp_department);

        // Initialize views
        ImageButton backButton = findViewById(R.id.backButton);
        recyclerView = findViewById(R.id.departmentRecyclerView);
        departmentNameInput = findViewById(R.id.departmentNameInput);
        submitButton = findViewById(R.id.submitButton);

        // Setup back button
        backButton.setOnClickListener(v -> finish());

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        departmentList = new ArrayList<>();
        adapter = new DepartmentAdapter(departmentList);
        recyclerView.setAdapter(adapter);

        // Add sample data
        departmentList.add(new Department("IT", "Active"));
        departmentList.add(new Department("HR", "Active"));
        departmentList.add(new Department("Finance", "Inactive"));
        adapter.notifyDataSetChanged();

        // Setup submit button
        submitButton.setOnClickListener(v -> {
            String departmentName = departmentNameInput.getText().toString().trim();
            if (!departmentName.isEmpty()) {
                departmentList.add(new Department(departmentName, "Active"));
                adapter.notifyItemInserted(departmentList.size() - 1);
                departmentNameInput.setText("");
                Toast.makeText(this, "Department added successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please enter department name", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private static class Department {
        String name;
        String status;

        Department(String name, String status) {
            this.name = name;
            this.status = status;
        }
    }

    private class DepartmentAdapter extends RecyclerView.Adapter<DepartmentAdapter.ViewHolder> {
        private List<Department> departments;

        DepartmentAdapter(List<Department> departments) {
            this.departments = departments;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_department, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Department department = departments.get(position);
            holder.nameText.setText(department.name);
            holder.statusText.setText(department.status);

            holder.editButton.setOnClickListener(v -> {
                // TODO: Implement edit functionality
                Toast.makeText(EmpDepartmentActivity.this, "Edit clicked for " + department.name, Toast.LENGTH_SHORT).show();
            });

            holder.deleteButton.setOnClickListener(v -> {
                // TODO: Implement delete functionality
                Toast.makeText(EmpDepartmentActivity.this, "Delete clicked for " + department.name, Toast.LENGTH_SHORT).show();
            });
        }

        @Override
        public int getItemCount() {
            return departments.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView nameText;
            TextView statusText;
            ImageButton editButton;
            ImageButton deleteButton;

            ViewHolder(View itemView) {
                super(itemView);
                nameText = itemView.findViewById(R.id.nameText);
                statusText = itemView.findViewById(R.id.statusText);
                editButton = itemView.findViewById(R.id.editButton);
                deleteButton = itemView.findViewById(R.id.deleteButton);
            }
        }
    }
} 