package com.example.kfinoneapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class BranchLocationActivity extends AppCompatActivity {
    private AutoCompleteTextView branchStateDropdown;
    private TextInputEditText locationInput;
    private MaterialButton submitButton;
    private RecyclerView branchLocationsRecyclerView;
    private BranchLocationAdapter adapter;
    private List<BranchLocation> branchLocations;
    private List<String> branchStates;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_branch_location);

        // Initialize views
        branchStateDropdown = findViewById(R.id.branchStateDropdown);
        locationInput = findViewById(R.id.locationInput);
        submitButton = findViewById(R.id.submitButton);
        branchLocationsRecyclerView = findViewById(R.id.branchLocationsRecyclerView);
        ImageButton backButton = findViewById(R.id.backButton);

        // Setup RecyclerView
        branchLocations = new ArrayList<>();
        adapter = new BranchLocationAdapter(branchLocations);
        branchLocationsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        branchLocationsRecyclerView.setAdapter(adapter);

        // Setup branch states dropdown
        branchStates = new ArrayList<>();
        branchStates.add("Maharashtra");
        branchStates.add("Karnataka");
        branchStates.add("Tamil Nadu");
        branchStates.add("Gujarat");
        branchStates.add("Delhi");

        ArrayAdapter<String> branchStateAdapter = new ArrayAdapter<>(
            this,
            android.R.layout.simple_dropdown_item_1line,
            branchStates
        );
        branchStateDropdown.setAdapter(branchStateAdapter);

        // Back button click listener
        backButton.setOnClickListener(v -> finish());

        // Submit button click listener
        submitButton.setOnClickListener(v -> {
            String selectedState = branchStateDropdown.getText().toString().trim();
            String locationName = locationInput.getText().toString().trim();

            if (selectedState.isEmpty()) {
                Toast.makeText(this, "Please select a branch state", Toast.LENGTH_SHORT).show();
                return;
            }

            if (locationName.isEmpty()) {
                Toast.makeText(this, "Please enter location name", Toast.LENGTH_SHORT).show();
                return;
            }

            // Add new branch location
            BranchLocation newBranchLocation = new BranchLocation(locationName, selectedState, "Active");
            branchLocations.add(newBranchLocation);
            adapter.notifyItemInserted(branchLocations.size() - 1);
            
            // Clear inputs
            branchStateDropdown.setText("");
            locationInput.setText("");
            
            Toast.makeText(this, "Branch Location added successfully", Toast.LENGTH_SHORT).show();
        });
    }

    // Branch Location data class
    private static class BranchLocation {
        private String location;
        private String state;
        private String status;

        public BranchLocation(String location, String state, String status) {
            this.location = location;
            this.state = state;
            this.status = status;
        }

        public String getLocation() {
            return location;
        }

        public String getState() {
            return state;
        }

        public String getStatus() {
            return status;
        }
    }

    // RecyclerView Adapter
    private class BranchLocationAdapter extends RecyclerView.Adapter<BranchLocationAdapter.ViewHolder> {
        private List<BranchLocation> branchLocations;

        public BranchLocationAdapter(List<BranchLocation> branchLocations) {
            this.branchLocations = branchLocations;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            View view = getLayoutInflater().inflate(R.layout.item_branch_location, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            BranchLocation branchLocation = branchLocations.get(position);
            holder.locationName.setText(branchLocation.getLocation());
            holder.stateName.setText(branchLocation.getState());
            holder.locationStatus.setText(branchLocation.getStatus());

            holder.editButton.setOnClickListener(v -> {
                // TODO: Implement edit functionality
                Toast.makeText(BranchLocationActivity.this, 
                    "Edit clicked for " + branchLocation.getLocation(), 
                    Toast.LENGTH_SHORT).show();
            });

            holder.deleteButton.setOnClickListener(v -> {
                branchLocations.remove(position);
                notifyItemRemoved(position);
                Toast.makeText(BranchLocationActivity.this, 
                    "Branch Location deleted", 
                    Toast.LENGTH_SHORT).show();
            });
        }

        @Override
        public int getItemCount() {
            return branchLocations.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView locationName;
            TextView stateName;
            TextView locationStatus;
            ImageButton editButton;
            ImageButton deleteButton;

            ViewHolder(View itemView) {
                super(itemView);
                locationName = itemView.findViewById(R.id.locationName);
                stateName = itemView.findViewById(R.id.stateName);
                locationStatus = itemView.findViewById(R.id.locationStatus);
                editButton = itemView.findViewById(R.id.editButton);
                deleteButton = itemView.findViewById(R.id.deleteButton);
            }
        }
    }
} 