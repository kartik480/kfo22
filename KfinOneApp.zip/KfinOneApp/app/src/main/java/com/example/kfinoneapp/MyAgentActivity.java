package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class MyAgentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_agent);

        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Initialize views
        AutoCompleteTextView agentTypeDropdown = findViewById(R.id.agentTypeDropdown);
        AutoCompleteTextView branchStateDropdown = findViewById(R.id.branchStateDropdown);
        AutoCompleteTextView branchLocationDropdown = findViewById(R.id.branchLocationDropdown);
        MaterialButton filterButton = findViewById(R.id.filterButton);
        MaterialButton resetButton = findViewById(R.id.resetButton);

        // Set up dropdown adapters
        String[] agentTypes = {"Type 1", "Type 2", "Type 3"}; // TODO: Replace with actual data
        String[] branchStates = {"State 1", "State 2", "State 3"}; // TODO: Replace with actual data
        String[] branchLocations = {"Location 1", "Location 2", "Location 3"}; // TODO: Replace with actual data

        ArrayAdapter<String> agentTypeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, agentTypes);
        ArrayAdapter<String> branchStateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, branchStates);
        ArrayAdapter<String> branchLocationAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, branchLocations);

        agentTypeDropdown.setAdapter(agentTypeAdapter);
        branchStateDropdown.setAdapter(branchStateAdapter);
        branchLocationDropdown.setAdapter(branchLocationAdapter);

        // Set up filter button click listener
        filterButton.setOnClickListener(v -> {
            String agentType = agentTypeDropdown.getText().toString();
            String branchState = branchStateDropdown.getText().toString();
            String branchLocation = branchLocationDropdown.getText().toString();
            // TODO: Implement filter functionality
        });

        // Set up reset button click listener
        resetButton.setOnClickListener(v -> {
            agentTypeDropdown.setText("");
            branchStateDropdown.setText("");
            branchLocationDropdown.setText("");
            // TODO: Reset the list to show all agents
        });
    }
} 