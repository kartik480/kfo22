package com.example.kfinoneapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ActiveEmpListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EmployeeAdapter adapter;
    private List<Employee> employeeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_active_emp_list);

        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.employeeRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize employee list with sample data
        employeeList = new ArrayList<>();
        employeeList.add(new Employee("John Doe", "EMP001", "1234567890", "john@example.com", "Active"));
        employeeList.add(new Employee("Jane Smith", "EMP002", "9876543210", "jane@example.com", "Active"));
        employeeList.add(new Employee("Mike Johnson", "EMP003", "5555555555", "mike@example.com", "Active"));

        // Set up adapter
        adapter = new EmployeeAdapter(employeeList);
        recyclerView.setAdapter(adapter);
    }

    // Employee data class
    private static class Employee {
        String fullName;
        String empId;
        String mobile;
        String email;
        String status;

        Employee(String fullName, String empId, String mobile, String email, String status) {
            this.fullName = fullName;
            this.empId = empId;
            this.mobile = mobile;
            this.email = email;
            this.status = status;
        }
    }

    // RecyclerView Adapter
    private class EmployeeAdapter extends RecyclerView.Adapter<EmployeeAdapter.ViewHolder> {
        private List<Employee> employees;

        EmployeeAdapter(List<Employee> employees) {
            this.employees = employees;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_user_table, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Employee employee = employees.get(position);
            holder.fullNameText.setText(employee.fullName);
            holder.empIdText.setText(employee.empId);
            holder.mobileText.setText(employee.mobile);
            holder.emailText.setText(employee.email);
            holder.statusText.setText(employee.status);

            holder.editButton.setOnClickListener(v -> {
                Toast.makeText(ActiveEmpListActivity.this, 
                    "Edit " + employee.fullName, Toast.LENGTH_SHORT).show();
            });

            holder.deleteButton.setOnClickListener(v -> {
                Toast.makeText(ActiveEmpListActivity.this, 
                    "Delete " + employee.fullName, Toast.LENGTH_SHORT).show();
            });
        }

        @Override
        public int getItemCount() {
            return employees.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView fullNameText;
            TextView empIdText;
            TextView mobileText;
            TextView emailText;
            TextView statusText;
            ImageButton editButton;
            ImageButton deleteButton;

            ViewHolder(View view) {
                super(view);
                fullNameText = view.findViewById(R.id.fullNameText);
                empIdText = view.findViewById(R.id.empIdText);
                mobileText = view.findViewById(R.id.mobileText);
                emailText = view.findViewById(R.id.emailText);
                statusText = view.findViewById(R.id.statusText);
                editButton = view.findViewById(R.id.editButton);
                deleteButton = view.findViewById(R.id.deleteButton);
            }
        }
    }
} 