package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.kfinoneapp.databinding.ActivityAddDsaBinding;
import com.google.android.material.textfield.TextInputEditText;

public class AddDsaActivity extends AppCompatActivity {
    private ActivityAddDsaBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddDsaBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize back button
        binding.backButton.setOnClickListener(v -> finish());

        // Initialize dropdowns with sample data
        setupDropdowns();

        // Initialize submit button
        binding.submitButton.setOnClickListener(v -> {
            if (validateInputs()) {
                // TODO: Implement submit functionality
                Toast.makeText(this, "Form submitted successfully", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private void setupDropdowns() {
        // Sample data for dropdowns
        String[] vendorBanks = {"HDFC Bank", "ICICI Bank", "SBI Bank", "Axis Bank"};
        String[] dsaNames = {"DSA 1", "DSA 2", "DSA 3", "DSA 4"};
        String[] loanTypes = {"Home Loan", "Personal Loan", "Business Loan", "Education Loan"};
        String[] states = {"Maharashtra", "Karnataka", "Tamil Nadu", "Delhi"};
        String[] locations = {"Mumbai", "Bangalore", "Chennai", "New Delhi"};

        // Setup Vendor Bank dropdown
        ArrayAdapter<String> vendorBankAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, vendorBanks);
        binding.vendorBankDropdown.setAdapter(vendorBankAdapter);

        // Setup DSA Name dropdown
        ArrayAdapter<String> dsaNameAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, dsaNames);
        binding.dsaNameDropdown.setAdapter(dsaNameAdapter);

        // Setup Type of Loans dropdown
        ArrayAdapter<String> loanTypeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, loanTypes);
        binding.typeOfLoansDropdown.setAdapter(loanTypeAdapter);

        // Setup Branch State dropdown
        ArrayAdapter<String> stateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, states);
        binding.branchStateDropdown.setAdapter(stateAdapter);

        // Setup Branch Location dropdown
        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, locations);
        binding.branchLocationDropdown.setAdapter(locationAdapter);
    }

    private boolean validateInputs() {
        boolean isValid = true;

        // Validate Vendor Bank
        if (binding.vendorBankDropdown.getText().toString().isEmpty()) {
            binding.vendorBankDropdown.setError("Please select a vendor bank");
            isValid = false;
        }

        // Validate DSA Code
        if (binding.dsaCodeInput.getText().toString().isEmpty()) {
            binding.dsaCodeInput.setError("Please enter DSA code");
            isValid = false;
        }

        // Validate DSA Name
        if (binding.dsaNameDropdown.getText().toString().isEmpty()) {
            binding.dsaNameDropdown.setError("Please select a DSA name");
            isValid = false;
        }

        // Validate Type of Loans
        if (binding.typeOfLoansDropdown.getText().toString().isEmpty()) {
            binding.typeOfLoansDropdown.setError("Please select type of loans");
            isValid = false;
        }

        // Validate Branch State
        if (binding.branchStateDropdown.getText().toString().isEmpty()) {
            binding.branchStateDropdown.setError("Please select a state");
            isValid = false;
        }

        // Validate Branch Location
        if (binding.branchLocationDropdown.getText().toString().isEmpty()) {
            binding.branchLocationDropdown.setError("Please select a location");
            isValid = false;
        }

        return isValid;
    }
} 