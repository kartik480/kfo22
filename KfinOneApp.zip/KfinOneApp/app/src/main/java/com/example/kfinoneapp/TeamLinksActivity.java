package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class TeamLinksActivity extends AppCompatActivity {

    private AutoCompleteTextView userDropdown;
    private MaterialButton showIconsButton;
    private MaterialButton resetButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_team_links);

        // Initialize views
        ImageButton backButton = findViewById(R.id.backButton);
        userDropdown = findViewById(R.id.userDropdown);
        showIconsButton = findViewById(R.id.showIconsButton);
        resetButton = findViewById(R.id.resetButton);

        // Setup back button
        backButton.setOnClickListener(v -> finish());

        // Setup user dropdown
        String[] users = {"User 1", "User 2", "User 3", "User 4", "User 5"}; // Example users
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, 
            android.R.layout.simple_dropdown_item_1line, users);
        userDropdown.setAdapter(adapter);

        // Setup show icons button
        showIconsButton.setOnClickListener(v -> {
            String selectedUser = userDropdown.getText().toString();
            if (selectedUser.isEmpty()) {
                Toast.makeText(this, "Please select a user", Toast.LENGTH_SHORT).show();
                return;
            }
            // TODO: Implement show icons functionality
            Toast.makeText(this, "Showing icons for: " + selectedUser, Toast.LENGTH_SHORT).show();
        });

        // Setup reset button
        resetButton.setOnClickListener(v -> {
            userDropdown.setText("");
            // TODO: Reset any other fields or states
            Toast.makeText(this, "Reset completed", Toast.LENGTH_SHORT).show();
        });
    }
} 