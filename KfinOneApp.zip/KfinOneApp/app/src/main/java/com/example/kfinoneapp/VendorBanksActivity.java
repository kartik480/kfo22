package com.example.kfinoneapp;

import android.os.Bundle;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class VendorBanksActivity extends AppCompatActivity {
    private TextInputEditText vendorBankNameInput;
    private MaterialButton submitButton;
    private RecyclerView vendorBanksRecyclerView;
    private VendorBanksAdapter vendorBanksAdapter;
    private List<VendorBankItem> vendorBanksList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_banks);

        // Initialize views
        initializeViews();
        
        // Set up back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Set up submit button
        submitButton.setOnClickListener(v -> handleSubmit());

        // Set up RecyclerView
        setupRecyclerView();
    }

    private void initializeViews() {
        vendorBankNameInput = findViewById(R.id.vendorBankNameInput);
        submitButton = findViewById(R.id.submitButton);
        vendorBanksRecyclerView = findViewById(R.id.vendorBanksRecyclerView);
    }

    private void setupRecyclerView() {
        vendorBanksList = new ArrayList<>();
        vendorBanksAdapter = new VendorBanksAdapter(vendorBanksList);
        vendorBanksRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        vendorBanksRecyclerView.setAdapter(vendorBanksAdapter);
    }

    private void handleSubmit() {
        String vendorBankName = vendorBankNameInput.getText().toString().trim();
        if (!vendorBankName.isEmpty()) {
            VendorBankItem newVendorBank = new VendorBankItem(vendorBankName, "Active");
            vendorBanksList.add(newVendorBank);
            vendorBanksAdapter.notifyItemInserted(vendorBanksList.size() - 1);
            vendorBankNameInput.setText("");
        }
    }
} 