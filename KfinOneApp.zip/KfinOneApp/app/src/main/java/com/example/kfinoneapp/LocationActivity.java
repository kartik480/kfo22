package com.example.kfinoneapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class LocationActivity extends AppCompatActivity {
    private AutoCompleteTextView stateDropdown;
    private TextInputEditText locationInput;
    private MaterialButton submitButton;
    private RecyclerView locationsRecyclerView;
    private LocationAdapter locationAdapter;
    private List<Location> locations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);

        // Initialize views
        stateDropdown = findViewById(R.id.stateDropdown);
        locationInput = findViewById(R.id.locationInput);
        submitButton = findViewById(R.id.submitButton);
        locationsRecyclerView = findViewById(R.id.locationsRecyclerView);

        // Setup back button
        findViewById(R.id.backButton).setOnClickListener(v -> finish());

        // Setup state dropdown
        String[] states = {"Maharashtra", "Karnataka", "Tamil Nadu", "Gujarat"}; // Example states
        ArrayAdapter<String> stateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, states);
        stateDropdown.setAdapter(stateAdapter);

        // Setup RecyclerView
        locations = new ArrayList<>();
        locationAdapter = new LocationAdapter(locations);
        locationsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        locationsRecyclerView.setAdapter(locationAdapter);

        // Add some sample data
        locations.add(new Location("Mumbai", "Maharashtra", "Active"));
        locations.add(new Location("Bangalore", "Karnataka", "Active"));
        locationAdapter.notifyDataSetChanged();

        // Setup submit button
        submitButton.setOnClickListener(v -> {
            String selectedState = stateDropdown.getText().toString();
            String locationName = locationInput.getText().toString();

            if (selectedState.isEmpty() || locationName.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Add new location
            locations.add(new Location(locationName, selectedState, "Active"));
            locationAdapter.notifyItemInserted(locations.size() - 1);

            // Clear inputs
            stateDropdown.setText("");
            locationInput.setText("");
        });
    }

    // Location data class
    private static class Location {
        String name;
        String state;
        String status;

        Location(String name, String state, String status) {
            this.name = name;
            this.state = state;
            this.status = status;
        }
    }

    // RecyclerView Adapter
    private class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.LocationViewHolder> {
        private List<Location> locations;

        LocationAdapter(List<Location> locations) {
            this.locations = locations;
        }

        @Override
        public LocationViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            View view = getLayoutInflater().inflate(R.layout.item_location, parent, false);
            return new LocationViewHolder(view);
        }

        @Override
        public void onBindViewHolder(LocationViewHolder holder, int position) {
            Location location = locations.get(position);
            holder.locationName.setText(location.name);
            holder.stateName.setText(location.state);
            holder.status.setText(location.status);

            holder.editButton.setOnClickListener(v -> {
                // TODO: Implement edit functionality
                Toast.makeText(LocationActivity.this, "Edit clicked for " + location.name, Toast.LENGTH_SHORT).show();
            });

            holder.deleteButton.setOnClickListener(v -> {
                locations.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, locations.size());
            });
        }

        @Override
        public int getItemCount() {
            return locations.size();
        }

        class LocationViewHolder extends RecyclerView.ViewHolder {
            TextView locationName;
            TextView stateName;
            TextView status;
            ImageButton editButton;
            ImageButton deleteButton;

            LocationViewHolder(View itemView) {
                super(itemView);
                locationName = itemView.findViewById(R.id.locationName);
                stateName = itemView.findViewById(R.id.stateName);
                status = itemView.findViewById(R.id.status);
                editButton = itemView.findViewById(R.id.editButton);
                deleteButton = itemView.findViewById(R.id.deleteButton);
            }
        }
    }
} 